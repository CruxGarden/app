# Glasshouse · a Tending demo

One plant shop. Several ideas growing at once.

This is a scripted example, authored for the demo. No AI ran during setup.
All files, Task conversations and Growth history are real and editable.
The shop is fictional: checkout never takes payment or sends an order.

## A five-minute walkthrough

1. Open Tending. Glasshouse contains Main and three current Tasks.
   The in-app demo marks Checkout and Accessibility as scripted results to review.
   Imported .crux files start idle: live job state is deliberately not portable.
2. Open Checkout. Add a plant to the bag and try the demo order in Preview.
   Switch to Main: checkout is still unfinished there. Each Task has its own files.
3. In Checkout, choose Review changes, inspect checkout.js, then Check combined
   result. Try the combined preview, acknowledge the review and Merge into Main.
   This static demo has no build step; the check is not an accessibility audit.
4. Repeat for Accessibility. It changes accessibility.css independently: keyboard
   focus, larger targets and reduced-motion support. Tab through the preview.
5. Open Growth → Whole Crux · branches & merges. Brand foundation was already
   merged during setup. Its branch remains visible after merging, as will yours.

## Try real parallel work

Open Autumn campaign and send the brief below using your configured collaborator.
Create another Task from Main for care tips and start that too. In Tending, watch
the real turns progress, open the right Collaboration, and review results.
Concurrency limits can queue a turn. Approvals appear only when a real agent
requests one. Keep the app window open while turns run.

Campaign prompt: Create an autumn collection page in campaign.html. Keep the
existing shop and cart working, use the existing palette, and change only
campaign.html and campaign.css. Explain how to preview your result.

Care tips prompt: Add care.html, a short care guide linked to the three plants,
with watering and light guidance. Keep checkout and the homepage unchanged.

## Take it with you

Export from Main to get one .crux file containing all Tasks and Growth, with
shared content stored by fingerprint. Import it as a copy in another garden.
No Git repository, worktrees, npm install or API key is needed for the saved demo.
An API key or configured local collaborator is needed for new live AI turns.
Publishing shares Main's website; the private .crux export carries the Task graph.
