const cart = [];
window.renderCart = function () {
  document.querySelector('#bag-count').textContent = String(cart.length);
  document.querySelector('#cart-summary').textContent = cart.length ? cart.length + ' in your bag · $' + cart.reduce((sum, item) => sum + item.price, 0) : 'Your bag is waiting for something green.';
};
document.querySelectorAll('[data-plant]').forEach(button => button.addEventListener('click', () => {
  cart.push({ name: button.dataset.plant, price: Number(button.dataset.price) });
  window.renderCart();
  document.querySelector('#cart-status').textContent = button.dataset.plant + ' added to your bag.';
}));
document.querySelector('#checkout').addEventListener('click', () => window.checkout(cart));