/* Checkout Task: a local simulation; no payment or network request. */
window.checkout = function (cart) {
  const status = document.querySelector('#cart-status');
  if (!cart.length) { status.textContent = 'Your bag is empty. Choose a little green first.'; return; }
  const count = cart.length;
  cart.splice(0);
  window.renderCart();
  status.textContent = 'Demo order placed: ' + count + (count === 1 ? ' plant' : ' plants') + '. Nothing was charged or sent. Keep growing!';
};
